package v1beta1

// Hub marks this type as a conversion hub.
func (*ArgoCD) Hub() {}
