# Generating OpenAPI Artifacts

Run the script to generate artifacts

``` bash
make generate
```
